# Sada on GitHub: what to click (about 15 minutes, free)

## 1. The place on GitHub (once)
Sada's own links already point to github.com/ayka-technologies/sada, so use that name.
- Signed in to GitHub, click your avatar → **Your organizations** → **New organization** → **Free**.
  Organization name: `ayka-technologies`. Contact email: hello@getayka.com. "Belongs to: a business" → AYKA TECHNOLOGIES.
- On the organization page: **Settings → Profile**: display name "AYKA TECHNOLOGIES", URL https://getayka.com, add the
  logo.
- Note: the files you upload show your own GitHub username as the uploader. If your username is your real name, keep
  your membership private (organization → People → your name → Private).

## 2. The repository
- In the organization: **New repository** → name `sada` → **Public** → do NOT add a README (we have one) → Create.
- On the empty repository page click **uploading an existing file**.
- Open the folder `upload-these-files`, select everything inside (Ctrl+A) and drag it onto the GitHub page
  (folders included, also `.github`). Wait until all files are listed, then click **Commit changes**.
- Check that GitHub shows the licence as "FSL-1.1-ALv2" on the right side ("License" link) and that README shows.
- On the repository page, click the gear next to "About": Website https://getayka.com/sada/, topics:
  `chrome-extension`, `geo`, `seo`, `ai-search`.

## 3. The release (this is the download people get)
- Right side of the repository: **Releases → Create a new release**.
- **Choose a tag**: type `v0.8.5` → "Create new tag". Title: `Sada 0.8.5`.
- Description: paste the "Install (2 minutes)" part of README.md, then the 0.8.5 part of CHANGELOG.md.
- Drag **sada.zip** (from this kit, not from the folder) into "Attach binaries". The file name must stay `sada.zip`.
- **Publish release**.
- Test: open https://github.com/ayka-technologies/sada/releases/latest/download/sada.zip; it should download.

## 3b. Repository settings (2 minutes)
- **Settings → General → Features**: keep **Issues** on (free bug reports and ideas); switch **Wiki**, **Projects** and
  **Discussions** off (nothing to look after).
- **Settings → General → Pull requests**: leave on; CONTRIBUTING.md tells people we don't merge outside code yet.
- **Settings → Code security**: switch on **Private vulnerability reporting**.
- **Settings → Branches → Add rule** for `main`: tick "Restrict deletions" and "Block force pushes".

## 4. Tell the Studio
Send your Telegram bot:

    /sada github.com/ayka-technologies/sada

With the next website version, every "Get Sada" button downloads from GitHub, and the 21:00 report counts downloads
("Sada downloads: N (+x since yesterday)").

## What is in the repository, and why
| File | Why it is there |
|---|---|
| the extension files | public code people can read and check (trust for clients' IT teams) |
| README.md | what Sada does, install steps in EN/FR/AR, download button, course link, agency contact |
| LICENSE.md | FSL-1.1-ALv2: free for any use except a competing product; Apache-2.0 after two years |
| TRADEMARKS.md | the code is shareable, the names Sada/AYKA and logos are not: copies must be renamed |
| THIRD-PARTY-NOTICES.md | the fonts and icons keep their own licences (required by those licences) |
| PRIVACY.md, SECURITY.md | trust: what Sada does with data, how to report a security issue privately |
| CONTRIBUTING.md | issues welcome, outside code not merged yet (keeps all rights with AYKA) |
| CHANGELOG.md | what changed in each version |
| .github/ISSUE_TEMPLATE | a clean bug form, plus links to a project with AYKA and the free course |

Nothing private is in it: no keys, no Studio code, no client data, no personal name.

## Each new Sada version
New release, new tag (e.g. `v0.8.5`), attach the new zip renamed to `sada.zip`. The download link never changes.
